#include "Menu.h"

int main(int argc,char** argv) {
    Menu menu(argc,argv);
    menu.startMenu();
    return 0;
}
